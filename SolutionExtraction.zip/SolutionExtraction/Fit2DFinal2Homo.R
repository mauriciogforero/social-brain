rm(list=ls())  #clear environment
graphics.off() #clear plots
cat("\014")    #clear console

#Choose the target species to fit with:
case<-1;  #1 if fit with H. sapiens;
          #2 if fit with H. neanderthalensis
          #3 if fit with H. erectus; 
          #4 if fit with H. heidelbergensis
          #5 if fit with H. ergaster;
          #6 if fit with H. habilis; 
          #7 if fit with H. floresiensis
          #8 if fit with H. naledi
          #9 if fit with A. afarensis

#Choose to calculate adult fit, ontogenetic fit, or ontogenetic variance in error:
goodness<-3;  #1 if fit through ontogeny
              #2 if old fit through ontogeny and adult EQ
              #3 if fit at adulthood
              #4 if old fit at adulthood and adult EQ
              #5 if old fit of adult EQ
              #6 if fit variance through ontogeny

#Choose value of vphi0 parameter:
vphi0<-0 #0 if benchmark; 0.5 if vphi0=0.5;  0.4 if vphi0=0.4;  0.45 if vphi0=0.45; 

if (case==1){caseName<-"1sapiens"
} else if (case==2){caseName<-"2neanderthalensis"
} else if (case==3){caseName<-"3erectus"
} else if (case==4){caseName<-"4heidelbergensis"
} else if (case==5){caseName<-"5ergaster"
} else if (case==6){caseName<-"6habilis"
} else if (case==7){caseName<-"7floresiensis"
} else if (case==8){caseName<-"8naledi"
} else if (case==9){caseName<-"9afarensis"}

if (goodness==1){goodnessName<-"OntogeneticFit"
} else if (goodness==2){goodnessName<-"FitOntogeneticAdultEQ"
} else if (goodness==3){goodnessName<-"FitAdult"
} else if (goodness==4){goodnessName<-"FitAdultEQ"
} else if (goodness==5){goodnessName<-"FitEQ"
} else if (goodness==6){goodnessName<-"FitVariance"}

#Define function to obtain data:
obtainData<-function(vphi0){
  
  if (vphi0==0) {
    mylist<-list.files(pattern="vphi0.benchmark.csv")}
  else if (vphi0==0.5) {
    mylist<-list.files(pattern="vphi0.0.5.csv")}
  else if (vphi0==0.4) {
    mylist<-list.files(pattern="vphi0.0.4.csv")}
  else if (vphi0==0.45) {
    mylist<-list.files(pattern="vphi0.0.45.csv")}
  
  R2b<-c()
  LLb<-c()
  R2B<-c()
  LLB<-c()
  R2<-c()
  LL<-c()
  diff<-c()
  diffEQ<-c()
  diffAlt<-c()
  etaIter<-c()
  
  for (i in 1:length(mylist)){
    mydata=read.csv(mylist[i], header=F)
    
    etas<-as.numeric(substr(mylist[i],6,8))
    etac<-as.numeric(substr(mylist[i],15,17))
    etaC<-as.numeric(substr(mylist[i],24,26))
    
    colnames(mydata) <- c("Age","Obs. brain","Obs. body","Pred. brain","Pred. body")
    
    brainVars<-data.frame(cbind(mydata$`Obs. brain`,mydata$`Pred. brain`))
    bodyVars<-data.frame(cbind(mydata$`Obs. body`,mydata$`Pred. body`))
    
    if (case==1){
      #H. sapiens
      adultBrain<-tail(brainVars,n=1)
      adultBody<-tail(bodyVars,n=1)
    } else if (case==2){
      #Neanderthals (PLOS data)
      adultBrain<-c(1.442,tail(brainVars,n=1)[[2]])
      adultBody<-c(66.4,tail(bodyVars,n=1)[[2]])
    } else if (case==3){
      #H. erectus (McHenry 1994 PNAS. Tempo and mode in human evolution)
      adultBrain<-c(0.980,tail(brainVars,n=1)[[2]])
      adultBody<-c(55,tail(bodyVars,n=1)[[2]])
    } else if (case==4){
      #H. heidelbergensis (https://www2.palomar.edu/anthro/homo2/mod_homo_1.htm)
      #adultBrain<-c(1.2,tail(brainVars,n=1)[[2]])
      #adultBody<-c(51,tail(bodyVars,n=1)[[2]])
      
      #H. heidelbergensis (not sexed: Rightmire, 2004, Brain Size and Encephalization in Early to Mid-Pleistocene Homo)
      #(1.0854+1.2554+1.0901+1.1893+1.0665+1.1289+1.2365+1.2082)/8
      adultBrain<-c(1.16,tail(brainVars,n=1)[[2]])
      #(45.65+58.82+40.04+51.93+34.95+34.95+83.79+83.79)/8
      adultBody<-c(54.24,tail(bodyVars,n=1)[[2]])
    } else if (case==5){
      #H. ergaster (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
      adultBrain<-c(0.849,tail(brainVars,n=1)[[2]])
      adultBody<-c(56,tail(bodyVars,n=1)[[2]])
    } else if (case==6){
      #H. habilis (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
      adultBrain<-c(0.601,tail(brainVars,n=1)[[2]])
      adultBody<-c(32,tail(bodyVars,n=1)[[2]])
    } else if (case==7){
      #H. floresiensis
      adultBrain<-c(0.400,tail(brainVars,n=1)[[2]])
      adultBody<-c(25,tail(bodyVars,n=1)[[2]])
    } else if (case==8){
      #H. naledi (Body size, brain size, and sexual dimorphism in Homo naledi from the Dinaledi Chamber)
      adultBrain<-c(0.500,tail(brainVars,n=1)[[2]])
      adultBody<-c(37.4,tail(bodyVars,n=1)[[2]])
    } else if (case==9){
      #A. afarensis (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
      adultBrain<-c(0.434,tail(brainVars,n=1)[[2]])
      adultBody<-c(29,tail(bodyVars,n=1)[[2]])
    }
    
    EQ<-adultBrain/(11.22*10^(-3)*(adultBody)^0.76)
    
    #zbta<-adultBrain[[1]]
    #zBta<-adultBody[[1]]
    
    diffb<-((adultBrain[1]-adultBrain[2])/adultBrain[1])^2
    diffB<-((adultBody[1]-adultBody[2])/adultBody[1])^2
    diffEQ[i]<-((EQ[1]-EQ[2])/EQ[1])^2
    
    diffbOnt<-((brainVars[1]-brainVars[2])/brainVars[1])^2
    diffBOnt<-((bodyVars[1]-bodyVars[2])/bodyVars[1])^2
    
    diff[i]<-diffB+diffb
    
    #rb<-data.matrix((brainVars[1]-brainVars[2])/brainVars[1])
    #rB<-data.matrix((bodyVars[1]-bodyVars[2])/bodyVars[1])
    #rEQ<-data.matrix((EQ[1]-EQ[2])/EQ[1])
    
    rb<-data.matrix((adultBrain[1]-adultBrain[2])/adultBrain[1])
    rB<-data.matrix((adultBody[1]-adultBody[2])/adultBody[1])
    rEQ<-data.matrix((EQ[1]-EQ[2])/EQ[1])

    rbA<-tail(rb,1)
    rBA<-tail(rB,1)
    
    E<-mean(sqrt(rb^2+rB^2))
    V<-var(sqrt(rb^2+rB^2))
    
    EA<-mean(sqrt(rbA^2+rBA^2))
    VA<-var(sqrt(rbA^2+rBA^2))
    
    R1<-c(rb,rB)
    R2<-c(rb,rB,rEQ)
    R3<-c(tail(rb),tail(rB))
    R4<-c(tail(rb),tail(rB),rEQ)
    R5<-c(rEQ)
    
    norm_vec <- function(x) sqrt(sum(x^2))
    
    #assign chosen fit criterion to reporting variable:
    if (goodness==1){diffAlt[i]<- -E}
    else if (goodness==2){diffAlt[i]<-norm_vec(R2)}
    else if (goodness==3){diffAlt[i]<- -EA}
    else if (goodness==4){diffAlt[i]<-norm_vec(R4)}
    else if (goodness==6){diffAlt[i]<- V}
    else diffAlt[i]<-norm_vec(R5)
    #diffAlt[i]<-diffB+diffb+diffEQ[i]
    #diffAlt[i]<-sum(diffBOnt+diffbOnt)#+diffEQ[i]
    
    if (i<2){fitAlt<-c(etas,etac,etaC,1-etas-etac-etaC,diffAlt[i])
    etaIterNum<-c(etas,etac,etaC,1-etas-etac-etaC)} 
    else {fitAlt<-cbind(fitAlt,c(etas,etac,etaC,1-etas-etac-etaC,diffAlt[i]))
    etaIterNum<-cbind(etaIterNum,c(etas,etac,etaC,1-etas-etac-etaC))}
    
    etaIter[i]<-paste("(",toString(c(etas,etac,etaC)),")")
    
    fitb<-lm(X1~X2,data=brainVars)
    sumfitb<-summary(fitb)
    R2b[i]<-sumfitb$adj.r.squared
    LLb[i]<-logLik(fitb)
    
    fitB<-lm(X1~X2,data=bodyVars)
    sumfitB<-summary(fitB)
    R2B[i]<-sumfitB$adj.r.squared
    LLB[i]<-logLik(fitB)
    
    R2[i]<-R2b[i]+R2B[i]
    LL[i]<-LLb[i]+LLB[i]
  }
  
  eta<-c("etas","etac","etaC","etag","error")
  rownames(fitAlt)<-eta
  rownames(etaIterNum)<-c("etas","etac","etaC","etag")
  etaNum<-round(etaIterNum,digits = 2)
  
  dat<-data.frame(fitAlt)
  #colnames(dat)<-c(etaIter,"eta")
  
  #library(reshape2)
  #dat2 <- melt(dat, id.vars = "eta")
  
  #dat3<-list("error"=dat2,"etaNum"=etaNum,"etaNumNoRound"=etaIterNum,
  #           "eta"=eta)
  
  return(dat)
  
}

#Move through folders to obtain data

#Move to 1RatioForm/3AdditiveCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/1RatioForm/3AdditiveCoop")
Result1<-obtainData(vphi0)

#Move to 1RatioForm/4MultCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/1RatioForm/4MultCoop")
Result2<-obtainData(vphi0)

#Move to 1RatioForm/5SubMultCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/1RatioForm/5SubMultCoop")
Result3<-obtainData(vphi0)

#Move to 2DiffForm/3AdditiveCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/2DiffForm/3AdditiveCoop")
Result4<-obtainData(vphi0)

#Move to 2DiffForm/4MultCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/2DiffForm/4MultCoop")
Result5<-obtainData(vphi0)

#Move to 2DiffForm/5SubMultCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/2DiffForm/5SubMultCoop")
Result6<-obtainData(vphi0)

#Move back to 1RatioForm/3AdditiveCoop:
setwd("~/Dropbox/Documents/LinuxFolderStAndrews/Brain/General/InteractWSameAgeResident/8NewSimpleMaternalCareLiuDifferentiationBreakLongAndInfsblManual/1RatioForm/3AdditiveCoop")

#The following is the columns in Result 6 reordered so that they are in 
#the order of increasing error
Result6[,order(Result6[nrow(Result6),])]

dResult1<-data.frame(etas = t(Result1)[,'etas'],
                               etac = t(Result1)[,'etac'],
                               etaC = t(Result1)[,'etaC'],
                               etag = t(Result1)[,'etag'],
                               error = t(Result1)[,'error'])
case1name<-"PC~AC"
dResult1$case<-case1name
row.names(dResult1)<-seq(from=1,to=length(dResult1$error))

dResult2<-data.frame(etas = t(Result2)[,'etas'],
                     etac = t(Result2)[,'etac'],
                     etaC = t(Result2)[,'etaC'],
                     etag = t(Result2)[,'etag'],
                     error = t(Result2)[,'error'])
case2name<-"PC~MC"
dResult2$case<-case2name
row.names(dResult2)<-seq(from=1,to=length(dResult2$error))

dResult3<-data.frame(etas = t(Result3)[,'etas'],
                     etac = t(Result3)[,'etac'],
                     etaC = t(Result3)[,'etaC'],
                     etag = t(Result3)[,'etag'],
                     error = t(Result3)[,'error'])
case3name<-"PC~SC"
dResult3$case<-case3name
row.names(dResult3)<-seq(from=1,to=length(dResult3$error))

dResult4<-data.frame(etas = t(Result4)[,'etas'],
                     etac = t(Result4)[,'etac'],
                     etaC = t(Result4)[,'etaC'],
                     etag = t(Result4)[,'etag'],
                     error = t(Result4)[,'error'])
case4name<-"EC~AC"
dResult4$case<-case4name
row.names(dResult4)<-seq(from=1,to=length(dResult4$error))

dResult5<-data.frame(etas = t(Result5)[,'etas'],
                     etac = t(Result5)[,'etac'],
                     etaC = t(Result5)[,'etaC'],
                     etag = t(Result5)[,'etag'],
                     error = t(Result5)[,'error'])
case5name<-"EC~MC"
dResult5$case<-case5name
row.names(dResult5)<-seq(from=1,to=length(dResult5$error))

dResult6<-data.frame(etas = t(Result6)[,'etas'],
                     etac = t(Result6)[,'etac'],
                     etaC = t(Result6)[,'etaC'],
                     etag = t(Result6)[,'etag'],
                     error = t(Result6)[,'error'])
case6name<-"EC~SC"
dResult6$case<-case6name
row.names(dResult6)<-seq(from=1,to=length(dResult6$error))

results<-rbind(dResult1,dResult2,dResult3,dResult4,dResult5,dResult6)

#Make a new factor to make rows in right order, and columns with spelled-out name:
#rows:
results$case_f<-factor(results$case, 
                        levels=c(case1name,case2name,case3name,case4name,case5name,case6name))
#columns:
#results$etaC_f<-factor(results$etaC, 
#                       labels=paste(expression(eta[coop]),"==",seq(from=0,to=1,by=0.1),sep=""))
results$etaC_f<-factor(results$etaC, 
                       labels=paste(expression(P[2]),"==",seq(from=0,to=1,by=0.1),sep=""))

#make white polygons to remove unpermitted parameter space:
polygons<-data.frame(
  etas=c(0,1,1,
         0,0,0.9,1,1,
         0,0,0.8,1,1,
         0,0,0.7,1,1,
         0,0,0.6,1,1,
         0,0,0.5,1,1,
         0,0,0.4,1,1,
         0,0,0.3,1,1,
         0,0,0.2,1,1,
         0,0,0.1,1,1,
         0,0,0.0,1,1),
  etac=c(1,0,1,
         1,0.9,0,0,1,
         1,0.8,0,0,1,
         1,0.7,0,0,1,
         1,0.6,0,0,1,
         1,0.5,0,0,1,
         1,0.4,0,0,1,
         1,0.3,0,0,1,
         1,0.2,0,0,1,
         1,0.1,0,0,1,
         1,0.0,0,0,1),
  etaC=c(0,0,0,
         0.1,0.1,0.1,0.1,0.1,
         0.2,0.2,0.2,0.2,0.2,
         0.3,0.3,0.3,0.3,0.3,
         0.4,0.4,0.4,0.4,0.4,
         0.5,0.5,0.5,0.5,0.5,
         0.6,0.6,0.6,0.6,0.6,
         0.7,0.7,0.7,0.7,0.7,
         0.8,0.8,0.8,0.8,0.8,
         0.9,0.9,0.9,0.9,0.9,
         1,1,1,1,1)
  )

#Name case columns
for (i in seq(from=0,to=1,by=0.1)){
polygons1<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons1$case<-case1name
polygons2<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons2$case<-case2name
polygons3<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons3$case<-case3name
polygons4<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons4$case<-case4name
polygons5<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons5$case<-case5name
polygons6<-polygons[which(round(polygons$etaC,digits=1)==round(i,digits=1)),]
polygons6$case<-case6name
polygTemp<-rbind(polygons1,polygons2,polygons3,polygons4,polygons5,polygons6)
if (i==0){Polygons<-polygTemp
} else Polygons<-rbind(Polygons,polygTemp)
}

#Make a new factor to make rows in right order:
#rows:
Polygons$case_f<-factor(Polygons$case, 
                       levels=c(case1name,case2name,case3name,case4name,case5name,case6name))

#columns:
#Polygons$etaC_f<-factor(Polygons$etaC, 
#                       labels=paste(expression(eta[coop]),"==",seq(from=0,to=1,by=0.1),sep=""))
Polygons$etaC_f<-factor(Polygons$etaC, 
                        labels=paste(expression(P[2]),"==",seq(from=0,to=1,by=0.1),sep=""))

#make gray triangles to highlight permitted parameter space:
triangles<-data.frame(
  etas=c(0,0,1,
         0,0,0.9,
         0,0,0.8,
         0,0,0.7,
         0,0,0.6,
         0,0,0.5,
         0,0,0.4,
         0,0,0.3,
         0,0,0.2,
         0,0,0.1,
         0,0,0.0),
  etac=c(0,1,0,
         0,0.9,0,
         0,0.8,0,
         0,0.7,0,
         0,0.6,0,
         0,0.5,0,
         0,0.4,0,
         0,0.3,0,
         0,0.2,0,
         0,0.1,0,
         0,0.0,0),
  etaC=c(0,0,0,
         0.1,0.1,0.1,
         0.2,0.2,0.2,
         0.3,0.3,0.3,
         0.4,0.4,0.4,
         0.5,0.5,0.5,
         0.6,0.6,0.6,
         0.7,0.7,0.7,
         0.8,0.8,0.8,
         0.9,0.9,0.9,
         1,1,1)
)

#Name case columns
for (i in seq(from=0,to=1,by=0.1)){
  triangles1<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles1$case<-case1name
  triangles2<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles2$case<-case2name
  triangles3<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles3$case<-case3name
  triangles4<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles4$case<-case4name
  triangles5<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles5$case<-case5name
  triangles6<-triangles[which(round(triangles$etaC,digits=1)==round(i,digits=1)),]
  triangles6$case<-case6name
  triangTemp<-rbind(triangles1,triangles2,triangles3,triangles4,triangles5,triangles6)
  if (i==0){Triangles<-triangTemp
  } else Triangles<-rbind(Triangles,triangTemp)
}

#Make a new factor to make rows in right order:
#rows:
Triangles$case_f<-factor(Triangles$case, 
                        levels=c(case1name,case2name,case3name,case4name,case5name,case6name))

#columns:
#Triangles$etaC_f<-factor(Triangles$etaC, 
#                        labels=paste(expression(eta[coop]),"==",seq(from=0,to=1,by=0.1),sep=""))
Triangles$etaC_f<-factor(Triangles$etaC, 
                         labels=paste(expression(P[2]),"==",seq(from=0,to=1,by=0.1),sep=""))

fontSizeLarge<-30
fontSize<-25
fontSizeSmall<-16

if (goodness==1){plottitle<-"Ontogeny fit"
#plotname<-"FitOntogeny2Neanderthal.pdf"
legendname<-"Ontogenetic fit"
colscale<-c("royalblue","springgreen","yellow","red")
collimits<-c(min(results$error),0)
} else if (goodness==2){plottitle<-"Ontogeny and EQ fit"
#plotname<-"FitOntogenyEQ2Neanderthal.pdf"
legendname<-"Error"
colscale<-c("red","yellow","springgreen","royalblue")
collimits<-c(0,max(results$error))
} else if (goodness==3){plottitle<-"Adult fit"
#plotname<-"FitAdult2Neanderthal.pdf"
legendname<-"Adult fit"
colscale<-c("royalblue","springgreen","yellow","red")
collimits<-c(min(results$error),0)
} else if (goodness==4){plottitle<-"Adult and EQ fit"
#plotname<-"FitAdultEQ2Neanderthal.pdf"
legendname<-"Error"
colscale<-c("red","yellow","springgreen","royalblue")
collimits<-c(min(results$error),0)
} else if (goodness==6){plottitle<-"Variance in ontogeny fit"
#plotname<-"FitOntogenyVariance2Neanderthal.pdf"
legendname<-"Variance"
colscale<-c("red","yellow","springgreen","royalblue")
collimits<-c(0,max(results$error))
} else {plottitle<-"EQ fit"
#plotname<-"FitEQ2Neanderthal.pdf"
legendname<-"Error"
colscale<-c("red","yellow","springgreen","royalblue")
collimits<-c(0,max(results$error))
}

plotname<-paste(goodnessName,caseName,".pdf",sep="")

library(ggplot2)

#make plot:
p<-ggplot(data = results, mapping = aes(x = etas, y = etac)) +
  geom_polygon(data=Polygons,mapping=aes(x = etas, y = etac),
               colour="white",fill="white") +
  geom_polygon(data=Triangles,mapping=aes(x = etas, y = etac),
               colour=alpha("gray",0.4),fill=alpha("gray",0.4)) +
  geom_point(aes(colour = error), pch=16,cex=4) + 
  facet_grid(case_f~etaC_f) + scale_colour_gradientn(colours=colscale,limits=collimits) +
  theme_bw() + theme(strip.background = element_blank()) +
  theme(text = element_text(size=fontSizeLarge)) +
  theme(strip.text.x = element_text(size=fontSize)) +
  theme(strip.text.y = element_text(size=fontSize)) +
  #theme(axis.text.x = element_text(size=fontSizeSmall,angle=45,hjust=1,vjust=1)) +
  theme(axis.text.x = element_text(size=fontSizeSmall,angle=0,hjust=0.5,vjust=0.5)) +
  theme(axis.text.y = element_text(size=fontSizeSmall)) +
  xlab(expression(paste("Probability of instrumental challenges, ",P[1]))) + 
  ylab(expression(paste("Probability of between-individual competition, ",P[3]))) + 
  xlim(0, 1) + ylim(0, 1) +
  scale_x_continuous(breaks=c(0,1)) + scale_y_continuous(breaks=c(0,1)) +
  facet_grid(case_f ~ etaC_f, labeller = label_parsed) + labs(color=legendname) +
  #ggtitle(plottitle) + 
  theme(plot.title = element_text(hjust = 0.5))
ggsave(plotname,width=25,height=13)

#Best fitting scenario:
results[which.max(results$error),]
