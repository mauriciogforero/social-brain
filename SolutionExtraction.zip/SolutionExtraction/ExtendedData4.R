rm(list=ls())  #clear environment
graphics.off() #clear plots
cat("\014")    #clear console

case<-2;  #1 if around best adult fit with H. sapiens; #2 if around me-vs-nature fit with H. sapiens
#3 if around best adult fit with H. neanderthalensis
#4 if around best adult fit with H. erectus; set challengeCase<-1
#5 if around best adult fit with H. heidelbergensis
#6 if around best adult fit with H. ergaster; set challengeCase<-1
#7 if around best adult fit with H. habilis; set challengeCase<-1
#8 if around best adult fit with H. floresiensis
#9 if around best adult fit with H. naledi
#10 if around best adult fit with A. afarensis

plotCase<-1 #1 if dot in good fit interval is best fitting run
#2 if dot in good fit interval is estimated best fitting run

for (ii in seq(1,6)){
  challengeCase<-ii  #1 if PCAC, 2 if PCMC, 3 if PCSC
  #4 if ECAC, 5 if ECMC, 6 if ECSC
  
  goodness<-3;  #1 if fit through ontogeny
  #2 if old fit through ontogeny and adult EQ
  #3 if fit at adulthood
  #4 if old fit at adulthood and adult EQ
  #5 if old fit of adult EQ
  #6 if fit variance through ontogeny
  
  vphi0<-0 #0 if benchmark; 0.5 if vphi0=0.5;  0.4 if vphi0=0.4;  0.45 if vphi0=0.45; 
  
  #Define function to obtain data:
  obtainData<-function(vphi0){
    
    if (vphi0==0) {
      mylist<-list.files(pattern="vphi0.benchmark.csv")}
    else if (vphi0==0.5) {
      mylist<-list.files(pattern="vphi0.0.5.csv")}
    else if (vphi0==0.4) {
      mylist<-list.files(pattern="vphi0.0.4.csv")}
    else if (vphi0==0.45) {
      mylist<-list.files(pattern="vphi0.0.45.csv")}
    
    R2b<-c()
    LLb<-c()
    R2B<-c()
    LLB<-c()
    R2<-c()
    LL<-c()
    diff<-c()
    diffEQ<-c()
    diffAlt<-c()
    etaIter<-c()
    
    for (i in 1:length(mylist)){
      mydata=read.csv(mylist[i], header=F)
      
      etas<-as.numeric(substr(mylist[i],6,8))
      etac<-as.numeric(substr(mylist[i],15,17))
      etaC<-as.numeric(substr(mylist[i],24,26))
      
      colnames(mydata) <- c("Age","Obs. brain","Obs. body","Pred. brain","Pred. body")
      
      brainVars<-data.frame(cbind(mydata$`Obs. brain`,mydata$`Pred. brain`))
      bodyVars<-data.frame(cbind(mydata$`Obs. body`,mydata$`Pred. body`))
      
      if (case==1 || case==2){
        #H. sapiens
        adultBrain<-tail(brainVars,n=1)
        adultBody<-tail(bodyVars,n=1)
      } else if (case==3){
        #Neanderthals (PLOS data)
        adultBrain<-c(1.442,tail(brainVars,n=1)[[2]])
        adultBody<-c(66.4,tail(bodyVars,n=1)[[2]])
      } else if (case==4){
        #H. erectus (McHenry 1994 PNAS. Tempo and mode in human evolution)
        adultBrain<-c(0.980,tail(brainVars,n=1)[[2]])
        adultBody<-c(55,tail(bodyVars,n=1)[[2]])
      } else if (case==5){
        #H. heidelbergensis (https://www2.palomar.edu/anthro/homo2/mod_homo_1.htm)
        #adultBrain<-c(1.2,tail(brainVars,n=1)[[2]])
        #adultBody<-c(51,tail(bodyVars,n=1)[[2]])
        
        #H. heidelbergensis (not sexed: Rightmire, 2004, Brain Size and Encephalization in Early to Mid-Pleistocene Homo)
        #(1.0854+1.2554+1.0901+1.1893+1.0665+1.1289+1.2365+1.2082)/8
        adultBrain<-c(1.16,tail(brainVars,n=1)[[2]])
        #(45.65+58.82+40.04+51.93+34.95+34.95+83.79+83.79)/8
        adultBody<-c(54.24,tail(bodyVars,n=1)[[2]])
      } else if (case==6){
        #H. ergaster (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
        adultBrain<-c(0.849,tail(brainVars,n=1)[[2]])
        adultBody<-c(56,tail(bodyVars,n=1)[[2]])
      } else if (case==7){
        #H. habilis (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
        adultBrain<-c(0.601,tail(brainVars,n=1)[[2]])
        adultBody<-c(32,tail(bodyVars,n=1)[[2]])
      } else if (case==8){
        #H. floresiensis
        adultBrain<-c(0.400,tail(brainVars,n=1)[[2]])
        adultBody<-c(25,tail(bodyVars,n=1)[[2]])
      } else if (case==9){
        #H. naledi (Body size, brain size, and sexual dimorphism in Homo naledi from the Dinaledi Chamber)
        adultBrain<-c(0.500,tail(brainVars,n=1)[[2]])
        adultBody<-c(37.4,tail(bodyVars,n=1)[[2]])
      } else if (case==10){
        #A. afarensis (McHenry & Coffing 2000 Ann Rev Anthr 29: 125)
        adultBrain<-c(0.434,tail(brainVars,n=1)[[2]])
        adultBody<-c(29,tail(bodyVars,n=1)[[2]])
      }
      
      EQ<-adultBrain/(11.22*10^(-3)*(adultBody)^0.76)
      
      diffb<-((adultBrain[1]-adultBrain[2])/adultBrain[1])^2
      diffB<-((adultBody[1]-adultBody[2])/adultBody[1])^2
      diffEQ[i]<-((EQ[1]-EQ[2])/EQ[1])^2
      
      diffbOnt<-((brainVars[1]-brainVars[2])/brainVars[1])^2
      diffBOnt<-((bodyVars[1]-bodyVars[2])/bodyVars[1])^2
      
      diff[i]<-diffB+diffb
      
      rb<-data.matrix((adultBrain[1]-adultBrain[2])/adultBrain[1])
      rB<-data.matrix((adultBody[1]-adultBody[2])/adultBody[1])
      rEQ<-data.matrix((EQ[1]-EQ[2])/EQ[1])
      
      rbA<-tail(rb,1)
      rBA<-tail(rB,1)
      
      E<-mean(sqrt(rb^2+rB^2))
      V<-var(sqrt(rb^2+rB^2))
      
      EA<-mean(sqrt(rbA^2+rBA^2))
      VA<-var(sqrt(rbA^2+rBA^2))
      
      R1<-c(rb,rB)
      R2<-c(rb,rB,rEQ)
      R3<-c(tail(rb),tail(rB))
      R4<-c(tail(rb),tail(rB),rEQ)
      R5<-c(rEQ)
      
      norm_vec <- function(x) sqrt(sum(x^2))
      
      #assign chosen fit criterion to reporting variable:
      if (goodness==1){diffAlt[i]<- -E}
      else if (goodness==2){diffAlt[i]<-norm_vec(R2)}
      else if (goodness==3){diffAlt[i]<- -EA}
      else if (goodness==4){diffAlt[i]<-norm_vec(R4)}
      else if (goodness==6){diffAlt[i]<-V}
      else diffAlt[i]<-norm_vec(R5)

      if (i<2){fitAlt<-c(etas,etac,etaC,1-etas-etac-etaC,
                         diffAlt[i],adultBrain[2],adultBody[2])
      etaIterNum<-c(etas,etac,etaC,1-etas-etac-etaC)} 
      else {fitAlt<-cbind(fitAlt,c(etas,etac,etaC,1-etas-etac-etaC,
                                   diffAlt[i],adultBrain[2],adultBody[2]))
      etaIterNum<-cbind(etaIterNum,c(etas,etac,etaC,1-etas-etac-etaC))}
      
      etaIter[i]<-paste("(",toString(c(etas,etac,etaC)),")")
      
      fitb<-lm(X1~X2,data=brainVars)
      sumfitb<-summary(fitb)
      R2b[i]<-sumfitb$adj.r.squared
      LLb[i]<-logLik(fitb)
      
      fitB<-lm(X1~X2,data=bodyVars)
      sumfitB<-summary(fitB)
      R2B[i]<-sumfitB$adj.r.squared
      LLB[i]<-logLik(fitB)
      
      R2[i]<-R2b[i]+R2B[i]
      LL[i]<-LLb[i]+LLB[i]
    }
    
    eta<-c("etas","etac","etaC","etag","error","brain","body")
    rownames(fitAlt)<-eta
    rownames(etaIterNum)<-c("etas","etac","etaC","etag")
    etaNum<-round(etaIterNum,digits = 2)
    
    dat<-data.frame(fitAlt)

    return(dat)
    
  }
  
  #Move through folders to obtain data
  
  #Move to folder with PC-AC data:
  PCACpath<-"" #enter path
  setwd(PCACpath)
  Result1<-obtainData(vphi0)
  
  #Move to folder with PC-MC data:
  PCMCpath<-"" #enter path
  setwd(PCMCpath)
  Result2<-obtainData(vphi0)
  
  #Move to folder with PC-SC data:
  PCSCpath<-"" #enter path
  setwd(PCSCpath)
  Result3<-obtainData(vphi0)
  
  #Move to folder with EC-AC data:
  ECACpath<-"" #enter path
  setwd(ECACpath)
  Result4<-obtainData(vphi0)
  
  #Move to folder with EC-MC data:
  ECMCpath<-"" #enter path
  setwd(ECMCpath)
  Result5<-obtainData(vphi0)
  
  #Move to folder with EC-SC data:
  ECSCpath<-"" #enter path
  setwd(ECSCpath)
  Result6<-obtainData(vphi0)
  
  #Move back to original folder:
  Originalpath<-"" #enter path
  setwd(Originalpath)

  errors<-c(as.numeric(t(Result1)[,5]),as.numeric(t(Result2)[,5]),
            as.numeric(t(Result3)[,5]),as.numeric(t(Result4)[,5]),
            as.numeric(t(Result5)[,5]),as.numeric(t(Result6)[,5]))
  
  Result<-eval(as.name(paste("Result",challengeCase,sep="")))
  
  dResult<-data.frame(etas = as.numeric(unlist(t(Result)[,'etas'])),
                      etac = as.numeric(unlist(t(Result)[,'etac'])),
                      etaC = as.numeric(unlist(t(Result)[,'etaC'])),
                      etag = as.numeric(unlist(t(Result)[,'etag'])),
                      error = as.numeric(unlist(t(Result)[,'error'])),
                      brain = as.numeric(unlist(t(Result)[,'brain'])),
                      body = as.numeric(unlist(t(Result)[,'body'])))
  
  dResult$EQ<-dResult$brain/(11.22*10^(-3)*dResult$body^0.76)
  dResult<-round(dResult,digits=2)
  
  library(ggplot2)
  
  #Prepare data frame for facet grid plot:
  
  if (challengeCase==1){
    partPlotName<-"PCAC"
  } else if (challengeCase==2){
    partPlotName<-"PCMC"
  } else if (challengeCase==3){
    partPlotName<-"PCSC"
  } else if (challengeCase==4){
    partPlotName<-"ECAC"
  } else if (challengeCase==5){
    partPlotName<-"ECMC"
  } else if (challengeCase==6){
    partPlotName<-"ECSC"
  }
  
  if (case==1){
    etaChere<-0.30
    etachere<-0.00
    etaghere<-0.10
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBest",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun1Sapiens",".pdf",sep="")
    plotGoodFitIntval<-paste("FigBestConfidence1Sapiens",".pdf",sep="")
  } else if (case==2){
    etaChere<-0.00
    etachere<-0.00
    etaghere<-0.00
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundMeVsNature",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun2SapiensAroundMeVsNature",".pdf",sep="")
    plotGoodFitIntval<-paste("FigBestConfidence2SapiensAroundMeVsNature",".pdf",sep="")
  } else if (case==3){
    etaChere<-0.20
    etachere<-0.00
    etaghere<-0.00
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBestNeanderthal",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun3Neanderthal",".pdf",sep="")
    plotGoodFitIntval<-paste("FigBestConfidence3Neanderthal",".pdf",sep="")
  } else if (case==4){
    etaChere<-0.20
    etachere<-0.00
    etaghere<-0.00
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBestErectus",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun4Erectus",".pdf",sep="")
    plotGoodFitIntval<-paste("FigBestConfidence4Erectus",".pdf",sep="")
  } else if (case==5){
    etaChere<-0.60
    etachere<-0.00
    etaghere<-0.00
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBestHeidelbergensis",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun5Heidelbergensis",".pdf",sep="")
    plotGoodFitIntval<-paste("FigBestConfidence5Heidelbergensis",".pdf",sep="")
  } else if (case==6){
    etaChere<-0.50
    etachere<-0.00
    etaghere<-0.00
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBestErgaster",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun6Ergaster",".pdf",sep="")
    plotGoodFitIntval<-paste("FigConfidence6Ergaster",".pdf",sep="")
  } else if (case==7){
    etaChere<-0.60
    etachere<-0.10
    etaghere<-0.20
    col1<-subset(dResult,etac==etachere & etag==etaghere)
    col2<-subset(dResult,etaC==etaChere & etag==etaghere)
    col3<-subset(dResult,etac==etachere & etaC==etaChere)
    plotname<-paste("Sensitivity",partPlotName,"AroundBestHabilis",".pdf",sep="")
    colscale<-c("royalblue","springgreen","yellow","red")
    plotFitFunname<-paste("FigBestAdultFitFun7Habilis",".pdf",sep="")
    plotGoodFitIntval<-paste("FigConfidence7Habilis",".pdf",sep="")
  }
  
  #Assign plots to columns and rows:
  dat1<-data.frame(x=col1$etaC,
                   y=col1$brain,
                   error=col1$error,
                   col="etaC",row="brain")
  
  dat2<-data.frame(x=col1$etaC,
                   y=col1$body,
                   error=col1$error,
                   col="etaC",row="body")
  
  dat3<-data.frame(x=col1$etaC,
                   y=col1$EQ,
                   error=col1$error,
                   col="etaC",row="EQ")
  
  dat4<-data.frame(x=col2$etac,
                   y=col2$brain,
                   error=col2$error,
                   col="etac",row="brain")
  
  dat5<-data.frame(x=col2$etac,
                   y=col2$body,
                   error=col2$error,
                   col="etac",row="body")
  
  dat6<-data.frame(x=col2$etac,
                   y=col2$EQ,
                   error=col2$error,
                   col="etac",row="EQ")
  
  dat7<-data.frame(x=col3$etag,
                   y=col3$brain,
                   error=col3$error,
                   col="etag",row="brain")
  
  dat8<-data.frame(x=col3$etag,
                   y=col3$body,
                   error=col3$error,
                   col="etag",row="body")
  
  dat9<-data.frame(x=col3$etag,
                   y=col3$EQ,
                   error=col3$error,
                   col="etag",row="EQ")
  
  #Obtain full data frame for facet grid:
  dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9)
  
  #Labels for the x axes:
  dat$col_f<-factor(dat$col, 
                    labels=expression(P[us-vs-nature], P[me-vs-you], P[us-vs-them]))
  
  #Labels for the y axes:
  dat$row_f<-factor(dat$row, 
                    labels=c('Brain~mass~~group("[",kg,"]")',
                             'Body~mass~~group("[",kg,"]")',
                             'EQ~~group("[", ,"]")'))
  
  fontSizeLarge<-7
  fontSize<-6
  
  lineSize<-0.25
  figWidth<-7.5/2.54
  figHeight<-4.5/2.54
  
  ggplot(data = dat, mapping = aes(x = x, y = y)) + geom_line(size=lineSize) +
    geom_point(aes(colour = error), pch=16,cex=1) +
    facet_grid(row_f~col_f, scales="free_y", switch="both", labeller = label_parsed) +
    theme_bw() + theme(strip.background = element_blank()) +
    theme(text = element_text(size=fontSize)) +
    theme(strip.text.x = element_blank()) +
    theme(strip.text.y = element_blank()) +
    theme(line = element_line(size=lineSize)) +
    theme(panel.border = element_rect(size=lineSize)) +
    theme(axis.text.x = element_text(angle=45,hjust=1,vjust=1.0)) +
    theme(plot.background = element_rect(fill = "transparent", colour = NA)) +
    theme(panel.background = element_rect(fill = "transparent", colour = NA)) +
    scale_colour_gradientn(colours=colscale,limits=c(-1.5,0),guide = FALSE) +
    xlab("") + ylab("") + expand_limits(x=0,y=0) + expand_limits(x=1)


    ggsave(plotname,width=figWidth,height=figHeight)

    #make plot for colorbar:
    ggplot(data = dat, mapping = aes(x = x, y = y)) + geom_line(size=lineSize) +
      geom_point(aes(colour = error), pch=16,cex=1) +
      facet_grid(row_f~col_f, scales="free_y", switch="both", labeller = label_parsed) +
      scale_colour_gradientn(colours=colscale,limits=c(-1.5,0), 
                             guide = guide_colorbar(barheight = 0.25, barwidth = 6,title=NULL,
                                                    label.theme=element_text(angle=0,size=5),
                                                    direction="horizontal")) +
  theme_bw() + theme(strip.background = element_blank()) +
      theme(text = element_text(size=fontSize)) +
      theme(strip.text = element_blank()) +
      theme(axis.text.x = element_text(size=fontSize,angle=90,hjust=0.5,vjust=0.5)) +
      theme(axis.text.y = element_text(size=fontSize)) +
      theme(line = element_line(size=lineSize)) +
      theme(panel.border = element_rect(size=lineSize)) +
      theme(plot.background = element_rect(fill = "transparent", colour = NA)) +
      theme(panel.background = element_rect(fill = "transparent", colour = NA)) +
      xlab("") + 
      ylab("") + 
      xlim(0, 1) + ylim(0, 1) 

    ggsave("BarLargeThin.pdf",width=figWidth,height=figHeight)
    
}
