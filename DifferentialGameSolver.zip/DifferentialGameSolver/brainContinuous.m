% File 4
% brainContinuous.m
% This file specifies the dynamic equations

function phaseout = brainContinuous(input)

% ----------------------------------------------------------------------- %
% Extract auxiliary data for problem
% ----------------------------------------------------------------------- %

alpha     = input.auxdata.alpha;
beta      = input.auxdata.beta;
gamma     = input.auxdata.gamma;
K         = input.auxdata.K;
Bs        = input.auxdata.Bs;
Bb        = input.auxdata.Bb;
Br        = input.auxdata.Br;
Es        = input.auxdata.Es;
Eb        = input.auxdata.Eb;
Er        = input.auxdata.Er;
mu        = input.auxdata.mu;
sk        = input.auxdata.sk;
Ek        = input.auxdata.Ek;
Bk        = input.auxdata.Bk;
f0        = input.auxdata.f0;
vphi0     = input.auxdata.vphi0;
vphir     = input.auxdata.vphir;

%Resident values
tRes      = input.auxdata.tRes;
xkRes     = input.auxdata.xkRes;
usRes     = input.auxdata.usRes;
ubRes     = input.auxdata.ubRes;

%etas=P1, etac=P3, etaC=P2
etas      = input.auxdata.etas;
etac      = input.auxdata.etac;
etaC      = input.auxdata.etaC;

somascale     = input.auxdata.somascale;
brainscale    = input.auxdata.brainscale;
reprscale     = input.auxdata.reprscale;

% ----------------------------------------------------------------------- %
% Extract state, control, and parameter for problem
% ----------------------------------------------------------------------- %

t  = input.phase.time;
l  = exp(-mu.*t);

xs = input.phase.state(:,1);
xb = input.phase.state(:,2);
xr = input.phase.state(:,3);
xk = input.phase.state(:,4);

us = input.phase.control(:,1);
ub = input.phase.control(:,2);

% ----------------------------------------------------------------------- %
% Differential equations
% ----------------------------------------------------------------------- %

% Find ages in resident that best approximate evaluation ages

index=zeros(1,length(t));
for j=1:length(t)
[c, index(j)] = min(abs(tRes-t(j)));
%[c, index(j)] = min((aRes-a(j)).^2);
end

%tR  = tRes(index);
xkR = xkRes(index);
ubR = ubRes(index);
usR = usRes(index);

vphi   = vphi0.*exp(-vphir.*t);

cs     = xk.^gamma;
ds     = alpha;
As     = (cs+ds.*vphi)./(cs+ds);

cc     = xk.^gamma;
dc     = xkR.^gamma;
Ac     = (cc+dc.*vphi)./(cc+dc);

cC     = (xk+xkR).^gamma;
dC     = alpha;
AC     = (cC+dC.*vphi)./(cC+dC);

cg     = (xk+xkR).^gamma;
dg     = (xkR+xkR).^gamma;
Ag     = (cg+dg.*vphi)./(cg+dg);

e     = etas.*As + etac.*Ac + etaC.*AC + (1-etas-etac-etaC).*Ag;
xB    = xs.*somascale+xb.*brainscale+xr.*reprscale;
Brest = e.*K.*xB.^beta;
Bsyn  = Brest-xs.*Bs-xb.*Bb-xr.*Br;

dxs = us.*Bsyn./Es;
dxb = ub.*Bsyn./Eb;
dxr = (1-us-ub).*Bsyn./Er;
dxk = sk./Ek.*(xb.*Bb+ub.*Bsyn)-xk.*Bk./Ek;

phaseout.dynamics  = [dxs,dxb,dxr,dxk];
phaseout.integrand = l.*f0.*xr;
phaseout.path      = [us+ub,abs(us-usR),abs(ub-ubR)]; % for path constraint: 0<=us+ub<=1


