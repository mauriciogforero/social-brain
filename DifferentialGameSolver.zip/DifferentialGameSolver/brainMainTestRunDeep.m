% File 2
% brainMainTestRunDeep.m
% This file tests for infeasibility warnings before launching
% one iteration of the differential game (mesh.maxiterations = 0)

function output = brainMainTestRunDeep(etas,etac,etaC)


clearvars -except INDEX epsilon out etas etac etaC

%-------------------------------------------------------------------------%
%---------------------- Provide Guess of Solution ------------------------%
%-------------------------------------------------------------------------%

guessing=load(['solutionDeep','.mat'],'output');

guess.phase.time     = guessing.output.result.solution.phase.time; 
guess.phase.state    = guessing.output.result.solution.phase.state;
guess.phase.control  = guessing.output.result.solution.phase.control;
guess.phase.integral = guessing.output.result.solution.phase.integral;

somascaleR  = 1000;
brainscaleR = 100;
reprscaleR  = 10;
skillscaleR = 10;

% ------------------------------------------------------------- %
%                  Parameters and initial conditions            %
% ------------------------------------------------------------- %

auxdata.somascale  = somascaleR;
auxdata.brainscale = brainscaleR;
auxdata.reprscale  = reprscaleR;
auxdata.skillscale = skillscaleR;

PAR=parameters(auxdata.somascale,auxdata.brainscale,...
                         auxdata.reprscale,auxdata.skillscale,...
                         etas,etac,etaC);

% Competence and cooperation

auxdata.comp = PAR.comp;
auxdata.coop = PAR.coop;

% Initial conditions
xs0=PAR.xs0;
xb0=PAR.xb0;
xr0=PAR.xr0;
xk0=PAR.xk0;

% Final time
T=PAR.T;

% Remaining parameters

auxdata.K   = PAR.K;

auxdata.Bs  = PAR.Bs;
auxdata.Bb  = PAR.Bb;
auxdata.Br  = PAR.Br;
auxdata.Es  = PAR.Es;
auxdata.Eb  = PAR.Eb;
auxdata.Er  = PAR.Er;

auxdata.mu  = PAR.mu;
auxdata.f0  = PAR.f0;

auxdata.vphi0  = PAR.vphi0;
auxdata.vphir  = PAR.vphir;

auxdata.sk  = PAR.sk;
auxdata.Bk  = PAR.Bk;
auxdata.Ek  = PAR.Ek;

auxdata.alpha = PAR.alpha;
auxdata.beta  = PAR.beta;
auxdata.gamma = PAR.gamma;

%etas=P1, etac=P3, etaC=P2
auxdata.etas  = PAR.etas;
auxdata.etac  = PAR.etac;
auxdata.etaC  = PAR.etaC;
delta         = PAR.delta;

% Determine values for the resident population
auxdata.tRes  = guess.phase.time;
auxdata.usRes = guess.phase.control(:,1);
auxdata.ubRes = guess.phase.control(:,2);
auxdata.xkRes = guess.phase.state(:,4);

%-------------------------------------------------------------------------%
%----------------- Provide All Bounds for Problem ------------------------%
%-------------------------------------------------------------------------%
t0 = 0; tf = T;
xsmin = 0; xsmax = 1000;
xbmin = 0; xbmax = 1000;
xrmin = 0; xrmax = 1000;
xkmin = 0; xkmax = 10000;
usmin = 0; usmax = 1;
ubmin = 0; ubmax = 1;

%-------------------------------------------------------------------------%
%----------------------- Setup for Problem Bounds ------------------------%
%-------------------------------------------------------------------------%
bounds.phase.initialtime.lower = t0;
bounds.phase.initialtime.upper = t0;
bounds.phase.finaltime.lower   = tf;
bounds.phase.finaltime.upper   = tf;

bounds.phase.initialstate.lower = [xs0,xb0,xr0,xk0];
bounds.phase.initialstate.upper = [xs0,xb0,xr0,xk0];
bounds.phase.state.lower        = [xsmin,xbmin,xrmin,xkmin];
bounds.phase.state.upper        = [xsmax,xbmax,xrmax,xkmax];
bounds.phase.finalstate.lower   = [xsmin,xbmin,xrmin,xkmin];
bounds.phase.finalstate.upper   = [xsmax,xbmax,xrmax,xkmax];

bounds.phase.control.lower = [usmin,ubmin];
bounds.phase.control.upper = [usmax,ubmax];

bounds.phase.integral.lower = 0;
bounds.phase.integral.upper = 1000;

% Specify that 0<=ua+ub<=1:
bounds.phase.path.lower = [0,0,0];
bounds.phase.path.upper = [1,delta,delta];

%-------------------------------------------------------------------------%
%----------Provide Mesh Refinement Method and Initial Mesh ---------------%
%-------------------------------------------------------------------------%
mesh.method          = 'hp-LiuRao';
mesh.tolerance       = 1e-6;
mesh.maxiterations   = 0; %Set to 0 to turn off adaptive mesh refinement
mesh.colpointsmin    = 2;
mesh.colpointsmax    = 14;
mesh.phase.colpoints = 4*ones(1,10);
mesh.phase.fraction  = 0.1*ones(1,10);

%-------------------------------------------------------------------------%
%------------- Assemble Information into Problem Structure ---------------%        
%-------------------------------------------------------------------------%
setup.name                           = 'Brain-Problem';
setup.functions.continuous           = @brainContinuous;
setup.functions.endpoint             = @brainEndpoint;
setup.displaylevel                   = 2;
setup.auxdata                        = auxdata;
setup.bounds                         = bounds;
setup.guess                          = guess;
setup.mesh                           = mesh;
setup.nlp.solver                     = 'ipopt';
setup.nlp.ipoptoptions.linear_solver = 'mumps';
setup.nlp.ipoptoptions.tolerance     = 1e-10;
setup.derivatives.supplier           = 'sparseCD';
setup.derivatives.derivativelevel    = 'second';
setup.method                         = 'RPM-Differentiation';

%-------------------------------------------------------------------------%
%---------------------- Solve Problem Using GPOPS2 -----------------------%
%-------------------------------------------------------------------------%
output = gpops2(setup);

%Timing
if output.totaltime>=60&&output.totaltime<60*60
    TIME=[num2str(output.totaltime/60),' minutes']
elseif output.totaltime>=60*60
    TIME=[num2str(output.totaltime/(60*60)),' hours']
else
    TIME=[num2str(output.totaltime),' seconds']
end
