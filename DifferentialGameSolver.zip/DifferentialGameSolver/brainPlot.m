% File 9
% This file plots the resulting life history
% brainPlot.m

clc 
clear all 
close all

load('solutionDeep','output');

%-------------------------------------------------------------------------%
%                              Plot Solution                              %
%-------------------------------------------------------------------------%
%% Get solution

sol=getSolution(output);

Bb=sol.Bb;

t=sol.t;

us=sol.us;
ub=sol.ub;

xs=sol.xs;
xb=sol.xb;
xr=sol.xr;
xk=sol.xk;

%Units of lambda=#offspring/mass (or skill) unit

lambdas=sol.lambdas;
lambdab=sol.lambdab;
lambdar=sol.lambdar;
lambdak=sol.lambdak;

sigmas=sol.sigmas;
sigmab=sol.sigmab;
sigmar=sol.sigmar;

J=sol.J;

xB=sol.xB;

e     = sol.e;
Brest = sol.Brest;
Bsyn  = sol.Bsyn;

%Fertility

f=sol.f;

%Ad hoc determined switching times

tb0=sol.tb0;
tb=sol.tb;
tm=sol.tm;
ta=sol.ta;

Mbrain=sol.Mbrain;
growthrate=sol.growthrate;

MASSSCALE='kg';

SKILLSCALE='skill';

%% Data (observed values of various quantities in H. sapiens)

%Age
datat=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 25];
%Body mass
datam=[2.4, 8.1, 11.9, 14.4, 16.1, 17.7, 19.8, 22.6, 26.1, 29.9, 33.8, 37.6, ...
    40.9, 43.6, 45.8, 47.4, 51.1];
%Brain mass
datab=[0.3372, 0.5848, 1.0598, 1.1042, 1.1257, 1.1468, 1.1673, 1.1870, 1.2059,...
    1.2238, 1.2405, 1.2560, 1.2702, 1.2829, 1.2939, 1.3032, 1.3100];

%% Plot 1

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])

plotrows=3;
plotcolumns=4;

fontSize=20;

subplot(plotrows,plotcolumns,1)
plot(t,xs,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t,xb,'--','Color',[1 0 0],'LineWidth',3)
plot(t,xr,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
plot(t,xB,'s','Color',[1 0.54902 0],'LineWidth',3)
scatter(datat,datam,40,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
ylim([-0.1*max(xB) 1.1*max(xB)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel(MASSSCALE,'FontSize',fontSize);
legend('\itx_s','\itx_b','\itx_r','\itx_B')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,2)
plot(t,xs,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t,xb,'--','Color',[1 0 0],'LineWidth',3)
plot(t,xr,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
plot(t,xB,'s','Color',[1 0.54902 0],'LineWidth',3)
scatter(datat,datab,40,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
ylim([-0.1*max(xb) 1.1*max(xb)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel(MASSSCALE,'FontSize',fontSize);
legend('\itx_s','\itx_b','\itx_r','\itx_B')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,3)
plot(t, us,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t, ub,'--','Color',[1 0 0],'LineWidth',3)
plot(t,1-us-ub,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
ylabel('%','FontSize',fontSize);
ylim([-0.1 1.1])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
legend('\itu_s','\itu_b','\itu_r')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,4)
plot(t,f,'-','Color',[0 0 1],'LineWidth',3)
hold on
title('\itf','FontSize',35);
ylabel('# offs./year','FontSize',fontSize);
ylim([-0.1*max(f(:,1)) 1.1*max(f(:,1))])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,5)
plot(t,xk,'-','Color',[0 0 1],'LineWidth',3)
hold on
ylim([-0.1*max(xk(:,1)) 1.1*max(xk(:,1))])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('skill','FontSize',fontSize);
title('\itx_k','FontSize',fontSize);
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,6)
plot(t,e,'-','Color',[0 0 1],'LineWidth',3)
hold on
ylabel('%','FontSize',fontSize);
ylim([-0.1 1.1])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
title('\ite','FontSize',fontSize);
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,8)
plot(t,xb*Bb,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t,ub.*Bsyn,'--','Color',[1 0 0],'LineWidth',3)
plot(t,Mbrain,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
ylim([-0.1*max(Mbrain) 1.1*max(Mbrain)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('J/year','FontSize',fontSize);
legend('\itx_bB_b','\itu_bB_{syn}','\itM_{brain}')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,9)
plot(t,xb./xB,'-','Color',[0 0 1],'LineWidth',3)
hold on
ylim([-0.1*max(xb./xB) 1.1*max(xb./xB)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('%','FontSize',fontSize);
title('\itx_b/x_B','FontSize',fontSize);
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,11)
plot(t,Bsyn,'-','Color',[0 0 1],'LineWidth',3)
hold on
ylim([-0.1*max(Bsyn) 1.1*max(Bsyn)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('J/year','FontSize',fontSize);
title('\itB_{syn}','FontSize',fontSize);
set(gca,'FontSize',fontSize)

% set(gcf,'PaperPositionMode','auto')
% eps_file=sprintf('plot1.eps');
% saveas(gcf,eps_file,'eps');
% print('-depsc2',eps_file);

%% Plot 2

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)])

plotrows=2;
plotcolumns=3;

subplot(plotrows,plotcolumns,1)
plot(t,lambdas,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t,lambdab,'--','Color',[1 0 0],'LineWidth',3)
plot(t,lambdar,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
plot(t,lambdak,'o-','Color',[0.5 0.54902 0],'LineWidth',3)
allLambda=[lambdas;lambdab;lambdar;lambdak];
ylim([1.1*min(allLambda) 1.1*max(allLambda)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./kg','FontSize',fontSize);
legend('\it\lambda_s','\it\lambda_b','\it\lambda_r','\it\lambda_k')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,2)
plot(t,lambdas,'-','Color',[0 0 1],'LineWidth',3)
hold on
ylim([1.1*min(lambdas) 1.1*max(lambdas)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./kg','FontSize',fontSize);
legend('\it\lambda_s')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,3)
plot(t,lambdab,'--','Color',[1 0 0],'LineWidth',3)
hold on
ylim([1.1*min(lambdab) 1.1*max(lambdab)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./kg','FontSize',fontSize);
legend('\it\lambda_b')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,4)
plot(t,lambdar,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
hold on
ylim([-1.1*max(lambdar) 1.1*max(lambdar)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./kg','FontSize',fontSize);
legend('\it\lambda_r')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,5)
plot(t,lambdak,'o-','Color',[0.5 0.54902 0],'LineWidth',3)
hold on
ylim([1.1*min(lambdak) 1.1*max(lambdak)])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./skill','FontSize',fontSize);
legend('\it\lambda_k')
set(gca,'FontSize',fontSize)

subplot(plotrows,plotcolumns,6)
plot(t,sigmas,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(t,sigmab,'--','Color',[1 0 0],'LineWidth',3)
plot(t,sigmar,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
plot(t,zeros(length(t),1),'--','Color',[0 0 0],'LineWidth',3)
ylim([1.1*min([sigmas;sigmab]) -1.1*min([sigmas;sigmab])])
hx=vline(t(tm),'k','t_m');
hb=vline(t(tb),'k','t_b');
hb0=vline(t(tb0),'k','t_{b0}');
ha=vline(t(ta),'k','t_a');
ylabel('# offs./MJ','FontSize',fontSize);
legend('\it\sigma_s','\it\sigma_b','\it\sigma_r')
set(gca,'FontSize',fontSize)

% set(gcf,'PaperPositionMode','auto')
% eps_file=sprintf('plot2.eps');
% saveas(gcf,eps_file,'eps');
% print('-depsc2',eps_file);
