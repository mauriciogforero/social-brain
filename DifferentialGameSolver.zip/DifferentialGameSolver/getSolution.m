% File 7
% getSolution.m
% This file extracts solution data for plots and other uses

function sol=getSolution(output)


auxdata=output.result.setup.auxdata;

%etas=P1, etac=P3, etaC=P2
if ~isfield(auxdata,'etas')
    etas = 1;
    etac = 0;
    etaC = 0;
    eta  = [etas,etac,etaC];
else
    etas = auxdata.etas;
    etac = auxdata.etac;
    etaC = auxdata.etaC;
    eta  = [etas,etac,etaC];
end

%% Get parameters

%Scaling
somascale  = auxdata.somascale;
brainscale = auxdata.brainscale;
reprscale  = auxdata.reprscale;
skillscale = auxdata.skillscale;

scaling    = [somascale,brainscale,reprscale,skillscale];

PAR=parameters(somascale,brainscale,reprscale,skillscale,...
               etas,etac,etaC);

comp=PAR.comp;

K  =PAR.K;
Bs =PAR.Bsu;
Bb =PAR.Bbu;
Br =PAR.Bru;
Es =PAR.Esu;
Eb =PAR.Ebu;
Er =PAR.Eru;
mu =PAR.mu;
f0 =PAR.f0u;

vphi0  =PAR.vphi0;
vphir  =PAR.vphir;

sk=PAR.sk;
Bk=PAR.Bku;
Ek=PAR.Eku;

beta=PAR.beta;
gamma=PAR.gammau;
alpha=PAR.alphau;

%Initial conditions
xs0=PAR.xs0u;
xb0=PAR.xb0u;
xr0=PAR.xr0u;
xk0=PAR.xk0u;

%Final time
T=PAR.T;

%% Get solution

us=output.result.solution.phase.control(:,1);
ub=output.result.solution.phase.control(:,2);

t=output.result.solution.phase.time;
l=exp(-mu.*t);

xs=output.result.solution.phase.state(:,1)*somascale;
xb=output.result.solution.phase.state(:,2)*brainscale;
xr=output.result.solution.phase.state(:,3)*reprscale;
xk=output.result.solution.phase.state(:,4)*skillscale;

%Units of lambda=#offspring/mass (or skill) unit

lambdas=-output.result.solution.phase.costate(:,1)/somascale;
lambdab=-output.result.solution.phase.costate(:,2)/brainscale;
lambdar=-output.result.solution.phase.costate(:,3)/reprscale;
lambdak=-output.result.solution.phase.costate(:,4)/skillscale;

sigmas=lambdas./Es-lambdar./Er;
sigmab=lambdab./Eb-lambdar./Er+lambdak*sk/Ek;
sigmar=lambdas./Es-lambdab./Eb-lambdak*sk/Ek;

J=output.result.solution.phase.integral*reprscale;

xB=xs+xb+xr;

vphi   = vphi0.*exp(-vphir.*t);

cs     = xk.^gamma;
ds     = alpha;
As     = (cs+ds.*vphi)./(cs+ds);

if etas ==1 
    Ac = 0; AC = 0; Ag = 0;
else
    tRes   = auxdata.tRes;
    xkRes  = auxdata.xkRes*skillscale;
    xkR    = pchip(tRes,xkRes,t);

    cc     = xk.^gamma;
    dc     = xkR.^gamma;
    Ac     = (cc+dc.*vphi)./(cc+dc);

    cC     = (xk+xkR).^gamma;
    dC     = alpha;
    AC     = (cC+dC.*vphi)./(cC+dC);

    cg     = (xk+xkR).^gamma;
    dg     = (xkR+xkR).^gamma;
    Ag     = (cg+dg.*vphi)./(cg+dg);
end

e     = etas.*As + etac.*Ac + etaC.*AC + (1-etas-etac-etaC).*Ag;

Brest = e.*K.*(xB.^beta);
Bsyn = Brest-xs*Bs-xb*Bb-xr*Br;

%Analytic controls
xt=[xs,xb,xr,xk,t];
lambda=[lambdas,lambdab,lambdar,lambdak];
sigma=[sigmas,sigmab,sigmar];

%Fertility

f=f0.*xr;
succ=l.*f;

%Ad hoc determination of switching times

error=0.01;
Fert=find(f>error*max(f));
if isempty(Fert)
    tm=max(size(t));
else
    tm=min(Fert);
end

repgrow=(1-us-ub).*Bsyn;
fullrep=find(abs(repgrow-Bsyn)<error*max(Bsyn));
if isempty(fullrep)
    ta=max(size(t));
else
    clear mature maturef
    fullrepf=flipud(fullrep);
    jj=0;
    for ii=0:length(fullrep)-1
        if fullrepf(1+ii)==length(t)-ii
            maturef(1+jj,1)=fullrepf(1+ii);
            jj=jj+1;
        end
    end
    if exist('maturef','var')
        mature=flipud(maturef);
        if mature==length(t)
            ta=min(mature);
        else
            ta=min(mature)+1;
        end
    else
        ta=max(size(t));
    end
end

bgrowth=find(ub.*Bsyn>error*max(ub.*Bsyn));
if isempty(bgrowth)
    tb=max(size(t));
    tb0=max(size(t));
elseif max(bgrowth)==length(t)
    tb=max(bgrowth);
    tb0=min(bgrowth);
else
    tb=max(bgrowth)+1;
    tb0=min(bgrowth);
end

%Brain metabolic rate
Mbrain=xb*Bb+ub.*Bsyn;
%Growth rate in body mass
growthrate=Bsyn.*(us./Es+ub./Eb+(1-us-ub)./Er);

sol.output=output;

sol.K=K;
sol.Bs=Bs;
sol.Bb=Bb;
sol.Br=Br;
sol.Bk=Bk;
sol.Es=Es;
sol.Eb=Eb;
sol.Er=Er;
sol.Ek=Ek;
sol.mu=mu;
sol.f0=f0;
sol.mu=mu;
sol.mu=mu;
sol.vphi0=vphi0;
sol.vphir=vphir;
sol.sk=sk;
sol.Bk=Bk;
sol.Ek=Ek;
sol.beta=beta;
sol.gamma=gamma;
sol.alpha=alpha;
sol.xs0=xs0;
sol.xb0=xb0;
sol.xr0=xr0;
sol.xk0=xk0;
sol.T=T;

sol.t=t;

sol.tm=tm;
sol.ta=ta;
sol.tb0=tb0;
sol.tb=tb;

sol.l=l;

sol.us=us;
sol.ub=ub;

sol.xs=xs;
sol.xb=xb;
sol.xr=xr;
sol.xk=xk;
sol.xB=xB;

sol.xBTa = xB(ta);
sol.xbTa = xb(ta);
sol.xkTa = xk(ta);
sol.EQ   = xb(ta)/(11.22*10^(-3)*(xB(ta))^0.76);

sol.lambdas=lambdas;
sol.lambdab=lambdab;
sol.lambdar=lambdar;
sol.lambdak=lambdak;

sol.sigmas=sigmas;
sol.sigmab=sigmab;
sol.sigmar=sigmar;

sol.J=J;

sol.e=e;
sol.Brest=Brest;
sol.Bsyn=Bsyn;
sol.Mbrain=Mbrain;
sol.growthrate=growthrate;

sol.f=f;

