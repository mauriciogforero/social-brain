% File 5
% brainEndpoint.m
% This file specifies the maximization objective

%---------------------------------%
% BEGIN: brainEndpoint.m %
%---------------------------------%
function output = brainEndpoint(input)

q  = input.phase.integral;
output.objective = -q;
%---------------------------------%
% END: brainEndpoint.m %
%---------------------------------%
