% File 6
% parameters.m
% This file enters the parameter values

function PAR = parameters(somascale,brainscale,reprscale,skillscale,...
               etas,etac,etaC)

%% Competence

PAR.comp        =   1;    % if competence function is c=xk^gamma
%PAR.comp        =   2;     % if competence function is c=exp(xk)gamma

%% Cooperation

PAR.coop        =   1;    % if cooperation is additive
%PAR.coop        =   2;   % if cooperation is multiplicative

%% Unrescaled parameters

PAR.Bsu         =   29.6891;
PAR.Bbu         =   313.0962;
PAR.Bru         =   2697.1179;

PAR.beta        =   0.7378;
PAR.K           =   132.7281;

PAR.Esu         =   12.4594;
PAR.Ebu         =   123.7584;
PAR.Eru         =   190.8196;

PAR.mu          =   0.034;
PAR.f0u         =   0.5;

PAR.vphi0       =   0.4; %0 means no care
PAR.vphir       =   0.2;

PAR.gammau      =   1.4;
PAR.alphau      =   1;

%etas=P1, etac=P3, etaC=P2
PAR.etas        =   etas;
PAR.etac        =   etac;
PAR.etaC        =   etaC;
PAR.delta       =   0.1;

%Initial conditions
PAR.xs0u        =   2.0628;
PAR.xb0u        =   0.3372;
PAR.xr0u        =   0;

PAR.sk          =   0.5;
PAR.Bku         =   36;
PAR.Eku         =   370;

PAR.xk0u        =   1;

% Final time
PAR.T           =   47;

%% Rescaled parameters

PAR.Bs          =   PAR.Bsu*somascale;
PAR.Bb          =   PAR.Bbu*brainscale;
PAR.Br          =   PAR.Bru*reprscale;
PAR.Bk          =   PAR.Bku*skillscale;

PAR.Es          =   PAR.Esu*somascale;
PAR.Eb          =   PAR.Ebu*brainscale;
PAR.Er          =   PAR.Eru*reprscale;
PAR.Ek          =   PAR.Eku*skillscale;

PAR.f0          =   PAR.f0u*reprscale;

%Initial conditions
PAR.xs0         =   PAR.xs0u/somascale;
PAR.xb0         =   PAR.xb0u/brainscale;
PAR.xr0         =   PAR.xr0u/reprscale;

PAR.xk0         =   PAR.xk0u/skillscale;

PAR.alpha       =   PAR.alphau*(1/skillscale)^PAR.gammau;
PAR.gamma       =   PAR.gammau;

