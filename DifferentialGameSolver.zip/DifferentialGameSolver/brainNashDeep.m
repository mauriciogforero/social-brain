% File 1
% This is the top file to solve the differential game problem
% brainMainNashDeep.m

% GPOPS code to be run in MATLAB
% Prepared for GPOPS 2.3 to be run in MATLAB R2015b 
% and Linux Debian 8.9

%etas=P1, etac=P3, etaC=P2
function brainNashDeep(etas,etac,etaC)

clc 
clearvars -except etas etac etaC
close all

NashFileName='solutionNashDeep';

firsttime=1; % 1 if first time running brainNashDeep, 0 otherwise
if firsttime
    copyfile('guessDeep.mat','solutionDeep.mat')
    INDEX=1;
    maxIterations=61;
else
    load solutionNashDeep.mat
end

diary([NashFileName,'.txt'])

STARTNash=datetime('now')

tic

epsilon = 5;

while INDEX<=maxIterations

display(['Start iteration: ',num2str(INDEX)])

%% Test run
% Do a test run to check if there are infeasibility warnings
% The test run only runs one mesh and checks if there are infeasibility
% warnings.
% If there are infeasibility warnings, the run for this eta (P) combination
% stops. If there are no infeasibility warnings, the main run is 
% performed.

display('Start test run')

%etas=P1, etac=P3, etaC=P2
outputTest = brainMainTestRunDeep(etas,etac,etaC);
diary off %To print any delayed output in text file

fid = fopen([NashFileName,'.txt'],'r');    %open stream file of test run
Ce  = textscan(fid,'%s','Delimiter','\n'); %asign file to variable Ce
fclose(fid);                               %close file of test run
Ce  = strfind(Ce{1},'infeasible');         %find if 'infeasible' appears in Ce
infeasible=any(~cellfun('isempty',Ce));    %if Ce is not empty 
                                           % (i.e., infeasibility
                                           % warning appears),
                                           % then set infeasible=true,
                                           % else false

diary([NashFileName,'.txt'])

NashTime=toc;
if NashTime>=60&&NashTime<60*60
    NashTIME=[num2str(NashTime/60),' minutes']
elseif NashTime>=60*60
    NashTIME=[num2str(NashTime/(60*60)),' hours']
else
    NashTIME=[num2str(NashTime),' seconds']
end

if infeasible
    display(sprintf(['Problem may be infeasible. ',...
         'Then, iterations will now stop.']))
    stopReason='Problem may be infeasible';
    break
end
    
display('Finished test run')

%% Main run
output=brainMainDeep(etas,etac,etaC);

sol  = getSolution(output);

% Standardized ages for comparying controls
tStd=0:0.001:sol.T;

us(:,INDEX)=interp1(sol.t,sol.us,tStd);
ub(:,INDEX)=interp1(sol.t,sol.ub,tStd);

xBTa(INDEX) = sol.xBTa;
xbTa(INDEX) = sol.xbTa;
xkTa(INDEX) = sol.xkTa;
EQ(INDEX)   = sol.EQ;

out{INDEX}=sol.output;

%Timing

NashTime=toc;
if NashTime>=60&&NashTime<60*60
    NashTIME=[num2str(NashTime/60),' minutes']
elseif NashTime>=60*60
    NashTIME=[num2str(NashTime/(60*60)),' hours']
else
    NashTIME=[num2str(NashTime),' seconds']
end

save([NashFileName,'.mat'])

display(['Finished iteration: ',num2str(INDEX)])

%Break if iteration ran for more than 12 hours
%or if iterations converged
maxIterationSpan=12; %hours

if output.totaltime>maxIterationSpan*60*60
    display(sprintf(['This iteration took more than ',...
        num2str(maxIterationSpan),' hours.\n',...
             'Then, iterations will now stop.']))
    stopReason=['Iteration took more than ',...
        num2str(maxIterationSpan),' hours'];
    INDEX=INDEX+1;
    save([NashFileName,'.mat'])
    break
elseif INDEX>5

    diffus = sum(abs(us(:,INDEX)-us(:,INDEX-1)));
    diffub = sum(abs(ub(:,INDEX)-ub(:,INDEX-1)));
    dif    = diffus+diffub;
  
    if (dif<epsilon)
        stopReason='Iterations converged to Nash';
        display(sprintf(stopReason))
        INDEX=INDEX+1;
        save([NashFileName,'.mat'])
        break
    end

end

INDEX=INDEX+1;
end

if INDEX>maxIterations
    stopReason='Maximum iteration reached';
    display(sprintf(stopReason))
end

ENDNash=datetime('now')

save([NashFileName,'Final.mat'])

diary off
