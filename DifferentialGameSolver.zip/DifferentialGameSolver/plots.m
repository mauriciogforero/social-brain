% File 8
% This file plots solutions across iterations of the differential game
% plots.m

clear all
close all
clc

load('solutionNashDeep.mat','out')

savefiles = 0; %0 if no, 1 if yes
%etas=P1, etac=P3, etaC=P2
ParSet = 'PCAC.etas.1.0.etac.0.0.etaC.0.0';

scrsz = get(0,'ScreenSize');

%% Data (observed values of various quantities in H. sapiens)

%Age
datat=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 25];
%Body mass
datam=[2.4, 8.1, 11.9, 14.4, 16.1, 17.7, 19.8, 22.6, 26.1, 29.9, 33.8, 37.6, ...
    40.9, 43.6, 45.8, 47.4, 51.1];
%Brain mass
datab=[0.3372, 0.5848, 1.0598, 1.1042, 1.1257, 1.1468, 1.1673, 1.1870, 1.2059,...
    1.2238, 1.2405, 1.2560, 1.2702, 1.2829, 1.2939, 1.3032, 1.3100];

%Age for skill (Tsimane data)
datatk=[4.986666667, 6.96, 7.946666667, 8.96, 10, 10.98666667, 12.02666667,...
    12.98666667, 14.02666667, 14.98666667, 16.08, 17.06666667, 18, ...
    18.98666667, 20, 22.02666667, 24.16, 25.65333333, 27.49333333, ...
    29.04, 29.94666667];

%Skill level (Tsimane data)
datak=[0.706214689, 3.220715631, 9.138983051, 11.66704331, 24.22297552, ...
    26.04519774, 40.57853107, 58.50282486, 67.1039548, 84.03954802, ...
    88.54387947, 91.4960452, 95.29642185, 95.56497175, 98.51676083, ...
    98.62937853, 98.74048964, 99.14312618, 99.25838041, 99.23653484, ...
    99.36497175];

%% Obtain variables to plot

% Determine states for starting population

%Prealocate variables
iterations = length(out);
sol     = cell(1+iterations,1);
t       = cell(1+iterations,1);
us      = cell(1+iterations,1);
ub      = cell(1+iterations,1);
xs      = cell(1+iterations,1);
xb      = cell(1+iterations,1);
xr      = cell(1+iterations,1);
xk      = cell(1+iterations,1);
xB      = cell(1+iterations,1);
lambdas = cell(1+iterations,1);
lambdab = cell(1+iterations,1);
lambdar = cell(1+iterations,1);
lambdak = cell(1+iterations,1);
e       = cell(1+iterations,1);
Bsyn    = cell(1+iterations,1);
khat    = cell(1+iterations,1);
datakN  = cell(1+iterations,1);
tm      = cell(1+iterations,1);
ta      = cell(1+iterations,1);
tb0     = cell(1+iterations,1);
tb      = cell(1+iterations,1);
u       = cell(1+iterations,1);

for i=1:(1+iterations)

    if i==1
        load('guessDeep.mat','output')
        sol{i}=getSolution(output);
    else
        clear output
        output=out{i-1};
        sol{i}=getSolution(output);
    end

t{i}  = sol{i}.t;

us{i} = sol{i}.us;
ub{i} = sol{i}.ub;
u{i}  = [us{i},ub{i}];

% Difference between u{i} and u{i-1}
if i==1
    dif(i)=NaN;
else
    tIndex=zeros(1,length(t{i}));
    for j=1:length(t{i})
    [c, tIndex(j)] = min(abs(t{i-1}-t{i}(j)));
    end

    diffus=sum(abs(us{i}-us{i-1}(tIndex)));
    diffub=sum(abs(ub{i}-ub{i-1}(tIndex)));

    dif(i)=diffus+diffub;
end

xs{i} = sol{i}.xs;
xb{i} = sol{i}.xb;
xr{i} = sol{i}.xr;
xk{i} = sol{i}.xk;

xB{i} = sol{i}.xB;

lambdas{i} = sol{i}.lambdas;
lambdab{i} = sol{i}.lambdab;
lambdar{i} = sol{i}.lambdar;
lambdak{i} = sol{i}.lambdak;

%Ad hoc determined switching times for starting population
tb0{i} = sol{i}.tb0;
tb{i}  = sol{i}.tb;
tm{i}  = sol{i}.tm;
ta{i}  = sol{i}.ta;

% Adult states

xbTa(i)=sol{i}.xbTa;
xkTa(i)=sol{i}.xkTa;
xBTa(i)=sol{i}.xBTa;

EQ(i) = sol{i}.EQ;

% Skill data rescaled for number of skills for starting population
khat{i}  = sol{i}.sk.*sol{i}.Bb...
           ./sol{i}.Bk.*xbTa(i);
datakN{i} = datak./max(datak).*khat{i};

e{i}     = sol{i}.e;
Bsyn{i}  = sol{i}.Bsyn;

J{i}     = sol{i}.J;

end

%Reporting variables for final iteration
NashEQ=EQ(end)
NashxBTa=xBTa(end)
NashxbTa=xbTa(end)
NashxkTa=xkTa(end)

%% Plot of the difference in resident and mutant controls
figure('Position',[1 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

subplot(5,1,1)
plot(dif,'-','Color',[0 0 0],'LineWidth',3)
h=legend('$u_j-u_{j-1}$');
set(h,'Interpreter','latex')
set(gca,'FontSize',20)

% if savefiles
%     set(gcf,'PaperPositionMode','auto')
%     pdf_file=sprintf([ParSet,'.Plot1.pdf']);
%     saveas(gcf,pdf_file,'pdf');
% end

%% Plot of x_B(t_a), x_b(t_a), x_k(t_a), and EQ(t_a)

fontSize=20;
dataEQ = datab(end)/(11.22*10^(-3)*(datam(end))^0.76);

subplot(5,1,2)
plot(xBTa,'-','Color',[0 0 1],'LineWidth',3)
hold on
plot(ones(1,length(xBTa))*datam(end),'k--')
ylim([-0.1*max(xBTa) 1.1*max(xBTa)])
h=legend('$x_\mathrm{B}(t_\mathrm{a})$','Location','southeast');
set(h,'Interpreter','latex')
set(gca,'FontSize',fontSize)

subplot(5,1,3)
plot(xbTa,'--','Color',[1 0 0],'LineWidth',3)
hold on
plot(ones(1,length(xBTa))*datab(end),'k--')
ylim([-0.1*max(xbTa) 1.1*max(xbTa)])
h=legend('$x_\mathrm{b}(t_\mathrm{a})$','Location','southeast');
set(h,'Interpreter','latex')
set(gca,'FontSize',fontSize)

subplot(5,1,4)
plot(xkTa,'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',3)
ylim([-0.1*max(xkTa) 1.1*max(xkTa)])
h=legend('$x_\mathrm{k}(t_\mathrm{a})$','Location','southeast');
set(h,'Interpreter','latex')
set(gca,'FontSize',fontSize)

subplot(5,1,5)
plot(EQ,'-.','Color',[1 0.54902 0],'LineWidth',3)
hold on
plot(ones(1,length(xBTa))*dataEQ,'k--')
ylim([-0.1*max(EQ) 1.1*max(EQ)])
xlabel('iteration','FontSize',35);
h=legend('$\mathrm{EQ}$','Location','southeast');
set(h,'Interpreter','latex')
set(gca,'FontSize',fontSize)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot1.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of u_i
n=iterations+1;
cols=3;
rows=ceil(n/3);

figure('Position',[0*scrsz(3)/5 0*scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot for iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},us{i},'-','Color',[0 0 1],'LineWidth',2)
hold on
plot(t{i},ub{i},'--','Color',[1 0 0],'LineWidth',2)
plot(t{i},1-us{i}-ub{i},'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',2)
ylim([-0.1 1.1])

end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$u_i$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot2.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of x_i, except x_k
figure('Position',[1*scrsz(3)/5 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

xBmax=70;
ylim([-0.1*max(xBmax) 1.1*max(xBmax)])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},xs{i},'-','Color',[0 0 1],'LineWidth',2)
hold on
plot(t{i},xb{i},'--','Color',[1 0 0],'LineWidth',2)
plot(t{i},xr{i},'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',2)
plot(t{i},xB{i},'-.','Color',[1 0.54902 0],'LineWidth',2)
scatter(datat,datam,20,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
ylim([-0.1*max(xBmax) 1.1*max(xBmax)])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.30,0.96,'$x_i$ except $x_{\mathrm{k}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot3.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of x_i, except x_k (zoom)
figure('Position',[2*scrsz(3)/5 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

xbmax=2.5;
ylim([-0.1*max(xbmax) 1.1*max(xbmax)])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},xs{i},'-','Color',[0 0 1],'LineWidth',2)
hold on
plot(t{i},xb{i},'--','Color',[1 0 0],'LineWidth',2)
plot(t{i},xr{i},'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',2)
plot(t{i},xB{i},'-.','Color',[1 0.54902 0],'LineWidth',2)
scatter(datat,datab,20,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
ylim([-0.1*max(xbmax) 1.1*max(xbmax)])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.15,0.96,'$x_i$ except $x_{\mathrm{k}}$ (zoom)','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot4.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of x_i, except x_k (extra zoom)
figure('Position',[3*scrsz(3)/5 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

xrmax=max(xr{1});
ylim([-0.1*max(xrmax) 1.1*max(xrmax)])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},xs{i},'-','Color',[0 0 1],'LineWidth',2)
hold on
plot(t{i},xb{i},'--','Color',[1 0 0],'LineWidth',2)
plot(t{i},xr{i},'-.','Color',[0.133333 0.545098 0.133333],'LineWidth',2)
plot(t{i},xB{i},'-.','Color',[1 0.54902 0],'LineWidth',2)
scatter(datat,datab,20,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
xrmax=max(xr{i});
ylim([-0.1*max(xrmax) 1.1*max(xrmax)])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.15,0.96,'$x_i$ except $x_{\mathrm{k}}$ (extra zoom)','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot5.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of x_k
figure('Position',[4*scrsz(3)/5 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

xkmax=8;
ylim([-0.1*max(xkmax) 1.1*max(xkmax)])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},xk{i},'-','Color',[0 0 1],'LineWidth',2)
hold on
scatter(datatk,datakN{i},20,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
ylim([-0.1*max(xkmax) 1.1*max(xkmax)])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$x_{\mathrm{k}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot6.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of lambdas
figure('Position',[1*scrsz(3)/5 0*scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},lambdas{i},'-','Color',[0 0 1],'LineWidth',2)

lambdasmax=max(lambdas{i});
lambdasmin=min(lambdas{i});
ylim([lambdasmin lambdasmax])
ylim([lambdasmin lambdasmax])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$\lambda_{\mathrm{s}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot7.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of lambdab
figure('Position',[2*scrsz(3)/5 0*scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},lambdab{i},'-','Color',[1 0 0],'LineWidth',2)

lambdabmax=max(lambdab{i});
lambdabmin=min(lambdab{i});
ylim([lambdabmin lambdabmax])
ylim([lambdabmin lambdabmax])

end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$\lambda_{\mathrm{b}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot8.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of lambdar
figure('Position',[3*scrsz(3)/5 0*scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},lambdar{i},'-','Color',[0.133333 0.545098 0.133333],'LineWidth',2)

lambdarmax=max(lambdar{i});
lambdarmin=min(lambdar{i});
ylim([lambdarmin lambdarmax])
ylim([lambdarmin lambdarmax])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$\lambda_{\mathrm{r}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot9.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of lambdak
figure('Position',[4*scrsz(3)/5 0*scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},lambdak{i},'-','Color',[0 0 1],'LineWidth',2)

lambdakmax=max(lambdak{i});
lambdakmin=min(lambdak{i});
ylim([lambdakmin lambdakmax])
ylim([lambdakmin lambdakmax])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$\lambda_{\mathrm{k}}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot10.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of growth metabolic rate
figure('Position',[1 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},Bsyn{i},'-','Color',[0 0 1],'LineWidth',2)
ylim([-0.1*max(Bsyn{i}) 1.1*max(Bsyn{i})])
    
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$B_\mathrm{syn}$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot11.pdf']);
    saveas(gcf,pdf_file,'pdf');
end

%% Plot of e
figure('Position',[1*scrsz(3)/5 scrsz(4)/2 scrsz(3)/5 scrsz(4)/2])

%Plot of iterations
for i=1:(1+iterations)
    
subplot(rows,cols,i)
plot(t{i},e{i},'-','Color',[0 0 1],'LineWidth',2)
ylim([-0.1 1.1])
   
end
ha=axes('Position',[0 0 1 1],'Xlim',[0,1],'Ylim',[0,1],...
    'Box','off','Visible','off','Units','normalized','clipping','off');

text(0.47,0.96,'$e$','Interpreter','latex','FontSize',35)
text(0.47,0.08,'age','FontSize',35)

if savefiles
    set(gcf,'PaperPositionMode','auto')
    pdf_file=sprintf([ParSet,'.Plot12.pdf']);
    saveas(gcf,pdf_file,'pdf');
end
